package com.route.islami_app_c38.UI.chapterDetails

import android.os.Build
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.annotation.RequiresApi
import androidx.recyclerview.widget.RecyclerView
import com.route.islami_app_c38.databinding.ItemChapterContentBinding

    class verser_Adapter (val verses : List<String>): RecyclerView.Adapter<verser_Adapter.ViewHolder>(){

        class ViewHolder(val binding:ItemChapterContentBinding)
            : RecyclerView.ViewHolder(binding.root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val binding = ItemChapterContentBinding.inflate(LayoutInflater.from(parent.context),parent,false)
            return ViewHolder(binding)
        }

        @RequiresApi(Build.VERSION_CODES.O)
        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            holder.binding.recycle.tooltipText =
                verses[position]
        }
        override fun getItemCount(): Int = verses.size
    }
