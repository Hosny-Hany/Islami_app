package com.route.islami_app_c38.UI.Home.Model

import java.io.Serializable

data class Hadeth(val title: Char, val content: String) : Serializable {

}